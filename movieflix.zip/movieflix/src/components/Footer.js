import React from 'react'

const Footer = () => {
  return (
    <>
      <div className="footer bg-danger bg-gradient">
        <h5>$copy; All rights reserved to movieflix</h5>
      </div>
    </>
  );
}

export default Footer